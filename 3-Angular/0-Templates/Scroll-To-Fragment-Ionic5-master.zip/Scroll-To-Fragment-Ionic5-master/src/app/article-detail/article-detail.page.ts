import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-article-detail',
  templateUrl: './article-detail.page.html',
  styleUrls: ['./article-detail.page.scss'],
})
export class ArticleDetailPage implements OnInit {

  lists = [
    {
      id: 1
    },
    {
      id: 2
    },
    {
      id: 3
    },
    {
      id: 4
    },
    {
      id: 5
    },
    {
      id: 6
    },
    {
      id: 7
    },
    {
      id: 8
    },
  ]

  id = this.router.snapshot.params.id;
  title = this.router.snapshot.queryParams.title;
  fragment = this.router.snapshot.fragment;
  constructor(private router: ActivatedRoute) { }

  ngOnInit() {
  }

}
