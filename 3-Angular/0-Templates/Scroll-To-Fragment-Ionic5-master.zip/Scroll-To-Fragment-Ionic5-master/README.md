You can scroll down to a specific fragment on a page, when you are redirected from another page. 
We have created 1 component and 2 pages inside this Ionic 5 app.
