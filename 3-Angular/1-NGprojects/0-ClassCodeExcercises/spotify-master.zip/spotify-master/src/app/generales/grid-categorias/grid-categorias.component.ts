import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-categorias',
  templateUrl: './grid-categorias.component.html',
  styleUrls: ['./grid-categorias.component.css']
})
export class GridCategoriasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
