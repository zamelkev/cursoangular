import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider-categorias',
  templateUrl: './slider-categorias.component.html',
  styleUrls: ['./slider-categorias.component.css']
})
export class SliderCategoriasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
