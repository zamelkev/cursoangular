import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componente-general',
  templateUrl: './componente-general.component.html',
  styleUrls: ['./componente-general.component.css']
})
export class ComponenteGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
