import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-link',
  templateUrl: './main-link.component.html',
  styleUrls: ['./main-link.component.css']
})
export class MainLinkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
