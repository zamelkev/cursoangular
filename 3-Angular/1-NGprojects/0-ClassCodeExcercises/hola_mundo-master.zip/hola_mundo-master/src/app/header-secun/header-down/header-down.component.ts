import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-down',
  templateUrl: './header-down.component.html',
  styleUrls: ['./header-down.component.css']
})
export class HeaderDownComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
