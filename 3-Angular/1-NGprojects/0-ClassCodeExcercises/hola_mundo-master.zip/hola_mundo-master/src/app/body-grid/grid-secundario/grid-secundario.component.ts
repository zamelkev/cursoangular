import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-secundario',
  templateUrl: './grid-secundario.component.html',
  styleUrls: ['./grid-secundario.component.css']
})
export class GridSecundarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
