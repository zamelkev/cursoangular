import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-principal',
  templateUrl: './grid-principal.component.html',
  styleUrls: ['./grid-principal.component.css']
})
export class GridPrincipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
